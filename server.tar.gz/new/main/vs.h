#ifndef _VS_H
#define _VS_H

int json_to_code(char* json);


#endif